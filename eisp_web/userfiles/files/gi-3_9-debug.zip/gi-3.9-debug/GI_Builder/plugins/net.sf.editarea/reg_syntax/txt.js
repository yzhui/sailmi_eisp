editAreaLoader.load_syntax["txt"] = {
	'COMMENT_SINGLE' : {}
	,'COMMENT_MULTI' : {}
	,'QUOTEMARKS' : []
	,'KEYWORD_CASE_SENSITIVE' : false
	,'KEYWORDS' : {
		'attributes' : []
		,'values' : []
		,'specials' : []
	}
	,'OPERATORS' :[]
	,'DELIMITERS' :[]
	,'STYLES' : {
	}
};
