Place user created prototypes in this folder. Any prototype files in this 
folder or nested folders (of arbitrary depth) will show up in the Component 
Libraries palette under the User node. Click the Reload button on the 
palette toolbar to re-scan prototypes from disk after placing a new 
prototype file in this folder.
