/*
 * Copyright (c) 2007-2009, TIBCO Software Inc.
 * Use, modification, and distribution subject to terms of license.
 */

// gi.test.gipp.BENCHMARK_JS = "benchmark.js";
// An array value also works, in which case show a multi-select
// gi.test.gipp.BENCHMARK_JS = ["benchmark.js", "benchmark2.js"];

// The relative location of the GI deployment directory.
gi.test.gipp.GI = "../gi";
// An array value also works, in which case show a select
// gi.test.gipp.GI = [];

// The relative location of the GI app to test ...
gi.test.gipp.APP = "JSXAPPS/matrix-benchmark";
// An array value also works, in which case show a select
// gi.test.gipp.APP = [];

// The number of runs.
// gi.test.gipp.RUNS = 1;

// Whether to start the tests automatically when the page loads.
// gi.test.gipp.AUTORUN = false;
