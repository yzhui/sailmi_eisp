jsx3.Class.defineClass("jsx3.ide.gipp.FileType",jsx3.ide.FileType,null,function(l,m){var
ub={a:/\/\* BEGIN GIPP RECORDER \*\/\s*var\s+recorderTests\s*=/};m.isTypeOf=function(j,e){var
pa=j.read();return pa&&pa.match(ub.a);};});
