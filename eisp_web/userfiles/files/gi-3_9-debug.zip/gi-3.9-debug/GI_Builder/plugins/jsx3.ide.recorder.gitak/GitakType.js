jsx3.Class.defineClass("jsx3.ide.gitak.FileType",jsx3.ide.FileType,null,function(l,m){var
ub={a:"html",b:"gitak",c:"true"};m.isTypeOf=function(j,e){return e!=null&&!e.hasError()&&e.getNodeName()==ub.a&&e.getAttribute(ub.b)==ub.c;};});
