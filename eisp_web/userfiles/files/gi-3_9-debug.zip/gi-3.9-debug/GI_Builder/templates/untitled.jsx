<?xml version="1.0" ?>
<serialization xmlns="urn:tibco.com/v3.0">
  <name><![CDATA[]]></name>
  <icon><![CDATA[]]></icon>
  <description><![CDATA[]]></description>
  <onBeforeDeserialize><![CDATA[]]></onBeforeDeserialize>
  <onAfterDeserialize><![CDATA[]]></onAfterDeserialize>
</serialization>
