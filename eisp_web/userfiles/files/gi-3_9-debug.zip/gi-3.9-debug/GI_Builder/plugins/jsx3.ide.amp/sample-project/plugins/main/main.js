(function(plugIn) {

  jsx3.$O(plugIn).extend({

    paint: function(objContainer) {
      this.loadRsrcComponent("layout", objContainer);
    }
    
  });

})(this);
