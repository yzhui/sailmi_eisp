Classes:
Date
jsx3.app.Server
jsx3.gui.Matrix
jsx3.gui.TextBox
jsx3.lang.Package
jsx3.net.Service
String

Methods:
Date.getDate()
Date.getMonth()
Date.getYear()
eg.wsdl2.doTest()
eg.wsdl2.initializeDate()
eg.wsdl2.onMyError()
eg.wsdl2.onMySuccess()
jsx3.app.Server.alert()
jsx3.app.Server.getJSXByName()
jsx3.gui.TextBox.setValue()
jsx3.lang.Package.definePackage()
jsx3.net.Request.getRequest()
jsx3.net.Request.getStatus()
jsx3.net.Service.doCall()
jsx3.net.Service.subscribe() 
jsx3.xml.Entity.getValue()

Constants:
MESSAGENODE
ON_SUCCESS
ON_ERROR

keywords:
WSDL,list, CDF, repeating structurs, rendering repeating structurs, mapping repeating structurs, 

Description:
WSD Mapping 2; version 2.0
JSX version: 3.4.0
This sample shows how to map repeating structures from WSDL to CDF and associate CDF documents and attributes with GUI components
