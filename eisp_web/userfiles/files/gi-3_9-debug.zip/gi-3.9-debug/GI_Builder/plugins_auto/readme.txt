Any AMP plug-ins placed in this directory will be registered automatically by the IDE.
