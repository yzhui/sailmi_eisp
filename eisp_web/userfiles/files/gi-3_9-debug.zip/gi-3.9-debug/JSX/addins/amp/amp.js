jsx3.lang.Package.definePackage("jsx3.amp",function(o){var
ub={a:"http://www.generalinterface.org/gi/amp",b:"amp",c:"plugins.xml",d:"plugin.xml",e:"plugins",f:"jsx3.amp",g:"string",h:"function",i:"",j:/\s/g};o.NS=ub.a;o.jw={"http://www.tibco.com/gi/amp":true,"http://www.generalinterface.org/gi/amp":true};o.isNS=function(c){return o.jw[c];};o.getXmlNS=function(h){var
Nb={};Nb[h.getNamespaceURI()]=ub.b;return Nb;};o.DESCRIPTOR=ub.c;o.METAFILE=ub.d;o.DIR=ub.e;o.LOG=jsx3.util.Logger.getLogger(ub.f);o.Gf=function(i){var
Q=i;if(typeof Q==ub.g)Q=jsx3.Class.forName(Q)||jsx3.lang.getVar(Q);if(Q instanceof jsx3.Class)Q=Q.getConstructor();if(typeof Q!=ub.h)Q=null;return Q;};o.Md=function(h,n){var
eb=(jsx3.$S(h||ub.i)).trim();if(eb.length>0){var
ia=jsx3.$A(eb.split(ub.j));var
Z=n.getSearchPath();var
ua=(jsx3.$A(Z)).find(function(i){return ia.contains(i.toString());});if(ua)return ua.toString();}return ub.i;};});jsx3.lang.Package.definePackage("jsx3.amp.util",function(e){});jsx3.lang.Class.defineInterface("jsx3.amp.Bindable",null,function(b,g){g.U6=function(){if(!this._bindings)this._bindings=jsx3.$H();return this._bindings;};g.addBindableProp=function(d,i){var
ub=this.U6();ub[d]={H0:d,LM:i};};g.getBindableProps=function(){return (this.U6()).keys();};g.updateBindableOn=function(p,o,c){o.subscribe(c,(jsx3.$F(this.updateBindable)).bind(this,[p]));};g.updateBindable=function(f){var
Q=(this.U6())[f];this.setBindableProp(f,this.eval(Q.LM));};g.setBindableProp=function(q,p){var
ab=this[q];if(ab!==p){this[q]=p;if(this.publish)this.publish({subject:q,oldValue:ab,value:p});}};});jsx3.lang.Class.defineClass("jsx3.amp.Ext",null,null,function(f,q){var
ub={a:".",b:"?",c:"id",d:"name",e:"point"};var
w=jsx3.amp;q.init=function(i,c){this._xml=new
w.XML(c);this.v8=i;};q.getId=function(){var
la=this.getLocalId();return this.getPlugIn()+ub.a+(la||ub.b);};q.getLocalId=function(){return this._xml.attr(ub.c);};q.getName=function(){return this._xml.attr(ub.d);};q.getPlugIn=function(){return this.v8;};q.getEngine=function(){return this.v8.getEngine();};q.getPointId=function(){return this._xml.attr(ub.e);};q.getPoint=function(){return (this.getEngine()).getExtPoint(this.getPointId());};q.getData=function(){return this._xml.children();};q.toString=function(){return this.getId();};});jsx3.lang.Class.defineClass("jsx3.amp.ExtPoint",null,[jsx3.util.EventDispatcher],function(c,f){var
ub={a:"extended",b:".",c:"id",d:"name",e:"processor",f:"type",g:"Parameter objProcessor must not be null."};var
w=jsx3.amp;c.EXTENDED=ub.a;f.init=function(s,m){this._xml=new
w.XML(m,true);this.v8=s;};f.getId=function(){return this.v8.getId()+ub.b+this.getLocalId();};f.getLocalId=function(){return this._xml.attr(ub.c);};f.getName=function(){return this._xml.attr(ub.d);};f.getPlugIn=function(){return this.v8;};f.getEngine=function(){return this.v8.getEngine();};f.getExts=function(){return (this.getEngine()).getExts(this.getId());};f.processExts=function(e,k){if(!e){var
Xa=this._xml.child(ub.e);if(Xa)e=w.ExtProc.getProcessor(Xa.attr(ub.f),Xa);if(!e)throw new
jsx3.Exception(ub.g);}if(!k)k=this.getExts();return w.ExtProc.process(k,e);};f.onExtension=function(m){this.publish({subject:c.EXTENDED,exts:m});};f.toString=function(){return this.getId();};});jsx3.lang.Class.defineClass("jsx3.amp.ExtProc",null,null,function(n,p){var
ub={a:"function",b:"instance-class",c:"ext-class",d:"amp.36",e:"load",f:"true"};var
ca=jsx3.amp;n.process=function(q,a){var
pb=jsx3.$A();for(var
C=0;C<q.length;C++){var
Gb=q[C];var
t=Gb.getData();for(var
Ga=0;Ga<t.length;Ga++){var
Ha=t[Ga];if(typeof a==ub.a){pb.push(a(Gb,Ha));}else pb.push(a.process(Gb,Ha));}}return pb;};n.Q8={eval:function(a){return n.EVAL;},"return":function(i){return n.RETURN;},"return-async":function(k){return n.RETURN_ASYNC;},instantiator:function(g){return n.newDescrProc(g.attr(ub.b));}};n.addProcessorFactory=function(l,c){n.Q8[l]=c;};n.getProcessor=function(e,i){var
ib=n.Q8[e];if(ib){return ib(i);}else return null;};n.iB=function(d){this._constructor=d;};n.iB.prototype.process=function(l,s){var
_=s.attr(ub.c);var
Ia=this._constructor;if(_){var
Hb=ca.Gf(_);if(Hb)Ia=Hb;else ca.LOG.error(jsx3._msg(ub.d,_));}return new
Ia(l,s);};n.EVAL={process:function(e,s){var
Q=s.attr(ub.e)==ub.f;var
Na=s.value();if(Q){((e.getPlugIn()).load()).when(function(){e.eval(Na);});}else e.eval(Na);}};n.RETURN={process:function(l,s){var
N=s.value();return l.eval(N);}};n.RETURN_ASYNC={process:jsx3.$Y(function(a){var
Wa=(a.args())[0];var
S=(a.args())[1];var
na=S.attr(ub.e)==ub.f;var
_a=S.value();if(na){((Wa.getPlugIn()).load()).when(function(){a.done(Wa.eval(_a));});}else a.done(Wa.eval(_a));})};n.newDescrProc=function(a){return new
n.iB(ca.Gf(a));};});jsx3.lang.Class.defineClass("jsx3.amp.PlugIn",null,[jsx3.util.EventDispatcher,jsx3.net.URIResolver,jsx3.amp.Bindable],function(i,o){var
ub={A:"amp.44",B:"{",C:"}",D:/[^\w\$]+/g,E:"with(this){",a:"ready",b:"extended",c:"id",d:"global",e:"true",f:"name",g:"version",h:"requires",i:"amp:plugin",j:"event",k:"extension-point",l:"class",m:"amp.38",n:"amp.39",o:"extension",p:"amp.40",q:"amp.41",r:"/",s:"vB",t:"amp.42",u:"jsxapp",v:"jsxplugin",w:"Parent container not specified for loading resource ",x:".",y:"No resource ",z:" in plug-in "};var
La=jsx3.amp;i.READY=ub.a;i.EXTENDED=ub.b;i.U1=0;i.CF=1;i.ls=2;o.init=function(){this.mu=i.U1;this.lw=jsx3.$A();this.KR=jsx3.$A();this.ry={};this.xt=jsx3.$A();this.N4={};this.DI=jsx3.$A();this.OC={};this.f3=jsx3.$A();};o.setData=function(p){this.H0=p.getAttribute(ub.c);this.pK=p.getAttribute(ub.d)==ub.e;this.yI=p.getAttribute(ub.f);this.Dw=p.getAttribute(ub.g);var
ya=(p.getChildNodes()).toArray(true);for(var
E=0;E<ya.length;E++){var
qa=ya[E];var
Na=qa.getBaseName();if(Na==ub.h){for(var
ca=qa.selectNodeIterator(ub.i,La.getXmlNS(qa));ca.hasNext();)this.lw.push((ca.next()).getAttribute(ub.c));}else if(Na==ub.j){this.f3.push(qa.getAttribute(ub.c));}else if(Na==ub.k){var
Ja=null;var
N=qa.getAttribute(ub.l);if(N){Ja=La.Gf(N);if(!Ja)La.LOG.error(jsx3._msg(ub.m,N));}if(!Ja)Ja=La.ExtPoint;var
lb=new
Ja(this,qa);var
Q=lb.getLocalId();if(this.N4[Q]){La.LOG.error(jsx3._msg(ub.n,this,Q));}else{La.Engine.Sh(lb,qa);this.N4[Q]=lb;this.xt.push(lb);}}else if(Na==ub.o){var
Xa=null;var
V=qa.getAttribute(ub.l);if(V){Xa=La.Gf(V);if(!Ja)La.LOG.error(jsx3._msg(ub.p,V));}if(!Xa)Xa=La.Ext;var
F=new
Xa(this,qa);var
Q=F.getLocalId();if(Q!=null)if(this.OC[Q]){La.LOG.error(jsx3._msg(ub.q,this,Q));}else this.OC[Q]=F;La.Engine.Sh(F,qa);this.DI.push(F);}}};o.setEngine=function(a){this.tr=a;};o.setPath=function(a){this.nM=a;this.io=new
jsx3.net.URI(a+ub.r);this.Co=(jsx3.app.Browser.getLocation()).resolve(this.io);};o.setResources=function(p){this.KR=jsx3.$A(p);this.ry={};for(var
Fb=0;Fb<p.length;Fb++){var
Pa=p[Fb];Pa.ih(this);if(!Pa.isLoaded())Pa.subscribe(La.Resource.READY,this,ub.s);this.ry[Pa.getLocalId()]=Pa;}};o.getId=function(){return this.H0;};o.isGlobal=function(){return this.pK;};o.getName=function(){return this.yI;};o.getVersion=function(){return this.Dw;};o.getResources=function(){return this.KR;};o.getEvents=function(){return this.f3;};o.getResource=function(a){return this.ry[a];};o.getRequires=function(){return this.lw;};o.load=jsx3.$Y(function(s){if(this.mu==i.U1){La.LOG.debug(jsx3._msg(ub.t,this));this.mu=i.CF;return this.tr.le(this);}else if(!this.isLoaded())this.subscribe(i.READY,(jsx3.$F(s.done)).bind(s));else s.done();});o.loaded=jsx3.$Y(function(c){if(this.isLoaded()){c.done();}else this.subscribe(i.READY,(jsx3.$F(c.done)).bind(c));});o.vB=function(k){};o.qm=function(){this.mu=i.ls;this.onLoaded();this.publish({subject:i.READY});};o.isLoaded=function(){return this.mu==i.ls;};o.getEngine=function(){return this.tr;};o.getServer=function(){return this.tr.getServer();};o.getExtPoints=function(){return this.xt;};o.getExtPoint=function(j){return this.N4[j];};o.addExtPoint=function(f){var
U=f.getLocalId();this.N4[U]=f;this.xt.push(f);this.tr.dg(f);};o.removeExtPoint=function(e){var
Fa=e.getLocalId();if(e===this.N4[Fa])delete this.N4[Fa];this.xt.remove(e);this.tr.Qh(e);};o.addExt=function(a){var
Ga=a.getLocalId();if(Ga!=null)if(this.OC[Ga]){La.LOG.error(jsx3._msg(ub.q,this,Ga));}else this.OC[Ga]=a;this.DI.push(a);this.tr.qn(a,true);};o.removeExt=function(r){var
X=r.getLocalId();if(r===this.OC[X])delete this.OC[X];this.DI.remove(r);this.tr.kj(r);};o.getExts=function(){return this.DI;};o.getExt=function(n){return this.OC[n];};o.onRegister=function(){};o.onLoaded=function(){};o.onStartup=function(){};o.onExtension=function(f,b){this.publish({subject:i.EXTENDED,extpt:f,exts:b});};o.resolveURI=function(n){var
Ja=jsx3.net.URI.valueOf(n);if(Ja.getScheme()==ub.u&&!Ja.getHost())return (this.getServer()).resolveURI((Ja.getPath()).substring(1));if(!jsx3.net.URIResolver.isAbsoluteURI(Ja))Ja=this.io.resolve(Ja);return jsx3.net.URIResolver.DEFAULT.resolveURI(Ja);};o.getUriPrefix=function(){return this.io.toString();};o.relativizeURI=function(e,c){var
Za=jsx3.app.Browser.getLocation();var
Fb=this.Co.relativize(Za.resolve(e));if(Fb.isAbsolute()||c)return Fb;else return jsx3.net.URI.fromParts(ub.v,null,this.getId(),null,ub.r+Fb.getPath(),Fb.getQuery(),Fb.getFragment());};o.toString=function(){return this.H0;};o.getLog=function(){return jsx3.util.Logger.getLogger(this.getId());};o.loadRsrcComponent=function(k,l,c){if(!l)throw new
jsx3.Exception(ub.w+k+ub.x);var
ma=k instanceof La.Resource?k:this.getResource(k);if(!ma)throw new
jsx3.Exception(ub.y+k+ub.z+this+ub.x);var
E=l.loadXML(ma.getData(),false,this);E.getPlugIn=(jsx3.$F(function(){return this;})).bind(this);if(E.onRsrcLoad)try{E.onRsrcLoad();}catch(Kb){La.LOG.error(jsx3._msg(ub.A,k),jsx3.NativeError.wrap(Kb));}if(c!==false)l.paintChild(E);return E;};i.isBindExpr=function(f){return f.indexOf(ub.B)==0&&(jsx3.$S(f)).endsWith(ub.C);};o.regBindExpr=function(g,j){var
Ha=g.substring(1,g.length-1);var
sb=jsx3.$H(Ha.split(ub.D));var
R=(this.getBindableProps()).filter(function(f){return sb[f];});var
Mb=(jsx3.$F(function(){var
aa=this.eval(ub.E+Ha+ub.C);j(aa);})).bind(this);if(R.length>0)R.each((jsx3.$F(function(k){this.subscribe(k,Mb);})).bind(this));Mb();};});jsx3.lang.Class.defineClass("jsx3.amp.ClassPlugIn",jsx3.amp.PlugIn,null,function(e,p){var
ub={a:"class",b:"jsx:/js/",c:/\./g,d:"/",e:".js",f:"script"};var
gb=jsx3.amp;p.isLoaded=function(){return jsx3.Class.forName(this.getId())!=null;};p.setResource=function(a){};p.getResources=function(){if(!this.KR||this.KR.length==0){var
v=new
gb.Resource(this,ub.a,{"@path":ub.b+(this.getId()).replace(ub.c,ub.d)+ub.e,"name()":ub.f});this.KR=jsx3.$A([v]);}return this.KR;};});jsx3.lang.Class.defineClass("jsx3.amp.XML",null,null,function(k,n){var
ub={a:"@",b:"name()",c:"/",d:"children()",e:"value()",f:""};n.init=function(b){if(b instanceof jsx3.xml.Entity)this._native=true;this._xml=b;};n.attr=function(q){return this._native?this._xml.getAttribute(q):this._xml[ub.a+q];};n.nname=function(){return this._native?this._xml.getBaseName():this._xml[ub.b];};n.child=function(a){if(this._native){for(var
L=this._xml.getChildIterator();L.hasNext();){var
Z=L.next();if(Z.getBaseName()==a)return new
k(Z);}return null;}else{var
bb=this._xml[ub.c+a];return bb?new
k(bb):null;}};n.children=function(){if(this._native)return (jsx3.$A((this._xml.getChildNodes()).toArray())).map(function(b){return new
k(b);});else return (jsx3.$A(this._xml[ub.d])).map(function(l){return new
k(l);});};n.value=function(){if(this._native)return this._xml.getValue();else return this._xml[ub.e];};n.toNative=function(){if(this._native)return this._xml;};n.toString=function(){if(this._native)return this._xml.toString();else return ub.f;};});jsx3.lang.Class.defineClass("jsx3.amp.Resource",null,[jsx3.util.EventDispatcher],function(s,i){var
ub={a:"ready",b:"script",c:"css",d:"xml",e:"xsl",f:"jss",g:"propsbundle",h:"early",i:"normal",j:"manual",k:"_j",l:"Po",m:"uT",n:".",o:"path",p:"",q:"locales",r:/\s+/g,s:"/",t:"load",u:"J6"};var
Aa=jsx3.amp;s.READY=ub.a;s.TYPE_SCRIPT=ub.b;s.TYPE_CSS=ub.c;s.TYPE_XML=ub.d;s.TYPE_XSL=ub.e;s.TYPE_JSS=ub.f;s.TYPE_BUNDLE=ub.g;s.LOAD_EARLY=ub.h;s.LOAD_NORMAL=ub.i;s.LOAD_MANUAL=ub.j;s.fQ={early:1,normal:1,manual:1};s.U1=0;s.CF=1;s.ls=2;s.wh=function(d,e,o,p,l){var
t=new
s(null,o,p);t._j=d;t.Po=e;t.uT=l;return t;};i.init=function(c,d,h){this.oB=new
Aa.XML(h||{});this.dV=h;this.v8=c;this.H0=d;this.dD=jsx3.$A();this.mu=s.U1;this.J6=null;};i.ih=function(p){this.v8=p;delete this[ub.k];delete this[ub.l];delete this[ub.m];};i.attr=function(j){return this.oB.attr(j);};i.xml=function(){return this.dV;};i.getPlugIn=function(){return this.v8;};i.getId=function(){return (this.v8?this.v8.getId():this._j)+ub.n+this.H0;};i.getLocalId=function(){return this.H0;};i.getPath=function(){return this.attr(ub.o);};i.getFullPath=function(d){var
Ea=d||this.getPath();return this.v8?ub.p+this.v8.resolveURI(Ea):this.Po+Ea;};i.getLocales=function(){var
ba=this.attr(ub.q);if(ba){ba=(jsx3.$S(ba)).trim();if(ba.length>0)return ba.split(ub.r);}return [];};i.getPathForLocale=function(d){var
Db=this.getPath();if(d){var
Ma=Aa.Md(this.attr(ub.q),d);if(Ma){var
pb=Db.lastIndexOf(ub.n);if(pb<0||pb<Db.lastIndexOf(ub.s))pb=Db.length;Db=Db.substring(0,pb)+ub.n+Ma+Db.substring(pb);}}return Db;};i.getType=function(){return this.oB.nname();};i.getLoadType=function(){var
Ib=this.attr(ub.t);return s.fQ[Ib]?Ib:s.LOAD_NORMAL;};i.bf=function(){return this.dD;};i.Bc=function(f,l){this.dD.push({id:f,type:l});};i.isLoaded=function(){return this.mu==s.ls;};i.loaded=jsx3.$Y(function(c){if(this.isLoaded()){c.done();}else this.subscribe(s.READY,(jsx3.$F(c.done)).bind(c));});i.load=jsx3.$Y(function(c){if(this.mu==s.U1){return (this.v8?this.v8.getEngine():this.uT).wo(this);}else if(!this.isLoaded())this.subscribe(s.READY,(jsx3.$F(c.done)).bind(c));else c.done();});i.Gg=function(h){this.mu=s.CF;};i.td=function(o){this.mu=s.ls;this.J6=o;this.publish({subject:s.READY});};i.getData=function(b){var
pb=this.J6;if(b)delete this[ub.u];return pb;};i.toString=function(){return this.getId();};});jsx3.lang.Class.defineClass("jsx3.amp.Engine",null,[jsx3.util.EventDispatcher],function(f,p){var
ub={A:"amp.07",Aa:"script",Ab:"h8",B:"locales",Ba:"amp.14",Bb:"amp.34",C:"/plugin.",Ca:"field",Cb:"amp.35",D:".xml",Da:"amp.15",E:"amp.53",Ea:"method",F:"amp.54",Fa:"lazy",G:"extension-point",Ga:"true",H:"extension",Ha:"params",I:"amp:",Ia:" = function(",J:"[@id]",Ja:") {",K:'[@id="',Ka:"async",L:'"]',La:"amp.16",M:"amp.55",Ma:"Already loaded plug-in ",N:"amp:resources",Na:"amp.11",O:"amp.26",Oa:"amp.12",P:"amp.08",Pa:"plugin.load",Q:"_assigned_",Qa:"amp.18",R:"_",Ra:"property",S:"amp:prereq",Sa:"amp.43",T:"rsrc",Ta:"amp.20",U:"amp:requires/amp:plugin",Ua:"amp.21",V:"global",Va:"shared",W:"amp.09",Wa:"system",X:"function",Xa:"r.",Y:"amp.10",Ya:"cache",Z:"amp:bindable",Za:"cachekey",_:"value",_a:"amp.52",a:"load",aa:"subscribe",ab:"amp.23",b:"error",ba:/\s+/g,bb:"css",c:"register",ca:"qw",cb:"jss",d:"progress",da:"[not(@handler)]",db:"propsbundle",e:"namespace",ea:"[@handler]",eb:"xml",f:"CK",fa:"amp:subscribe",fb:"xsl",g:"jsxplugin",ga:"event",gb:"eval",h:"jsx3.amp.Engine",ha:"handler",hb:"js.eval",i:"/",ia:"when",ib:"amp.32",j:'<?xml version="1.0" encoding="UTF-8"?><plugins xmlns="http://www.generalinterface.org/gi/amp" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.generalinterface.org/gi/amp http://www.generalinterface.org/xsd/plugins.xsd">\n\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.HotKey"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Heavyweight"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Interactive">\n    <requires>\n      <plugin id="jsx3.gui.HotKey"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Painted"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Block">\n    <requires>\n      <plugin id="jsx3.gui.Interactive"/>\n      <plugin id="jsx3.gui.Painted"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Label">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.app.UserSettings"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.net.Form"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.xml.Cacheable"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Form"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Alerts"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.BlockX">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.xml.Cacheable"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.ToolbarButton">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.WindowBar">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Dialog">\n    <requires>\n      <plugin id="jsx3.gui.Alerts"/>\n      <plugin id="jsx3.gui.ToolbarButton"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Button">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.NativeButton">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.NativeFileUpload">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.NativeHidden">\n    <requires>\n      <plugin id="jsx3.gui.Painted"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.NativeForm">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.TextBox">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.NumberInput">\n    <requires>\n      <plugin id="jsx3.gui.TextBox"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.CheckBox">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.RadioButton">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Splitter">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.LayoutGrid">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Stack">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.StackGroup">\n    <requires>\n      <plugin id="jsx3.gui.LayoutGrid"/>\n      <plugin id="jsx3.gui.Stack"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Tab">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.TabbedPane">\n    <requires>\n      <plugin id="jsx3.gui.Tab"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Select">\n    <requires>\n      <plugin id="jsx3.gui.Heavyweight"/>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.xml.Cacheable"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.NativeSelect">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.xml.Cacheable"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Menu">\n    <requires>\n      <plugin id="jsx3.gui.Heavyweight"/>\n      <plugin id="jsx3.xml.Cacheable"/>\n      <plugin id="jsx3.gui.Form"/>\n      <plugin id="jsx3.gui.ToolbarButton"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Tree">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.xml.Cacheable"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.DatePicker">\n    <requires>\n      <plugin id="jsx3.gui.Heavyweight"/>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Slider">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Sound">\n    <requires>\n      <plugin id="jsx3.gui.Interactive"/>\n      <plugin id="jsx3.gui.Painted"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Window"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.ImageButton">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.ColorPicker">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.TimePicker">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Matrix.Column">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Matrix">\n    <requires>\n      <plugin id="jsx3.xml.Cacheable"/>\n      <plugin id="jsx3.gui.Form"/>\n      <plugin id="jsx3.gui.Matrix.Column"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Image">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.net.Service"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Table">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.xml.Cacheable"/>\n      <plugin id="jsx3.gui.Form"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.html.DOM"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.html.Style"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.Template">\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n      <plugin id="jsx3.html.DOM"/>\n      <plugin id="jsx3.html.Style"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.util.Dojo"/>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.xml.DojoDataStore">\n    <requires>\n      <plugin id="jsx3.util.Dojo"/>\n    </requires>\n  </plugin>\n  <plugin class="jsx3.amp.ClassPlugIn" id="jsx3.gui.DojoWidget">\n    <requires>\n      <plugin id="jsx3.util.Dojo"/>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n  </plugin>\n\n  <plugin id="jsx3.gui.Alerts.alert">\n    <requires>\n      <plugin id="jsx3.gui.Button"/>\n      <plugin id="jsx3.gui.Alerts"/>\n    </requires>\n    <resources>\n      <xml cache="shared" id="xml" path="jsx:/xml/components/dialog_alert.xml"/>\n    </resources>\n  </plugin>\n  <plugin id="jsx3.gui.Alerts.confirm">\n    <requires>\n      <plugin id="jsx3.gui.Button"/>\n      <plugin id="jsx3.gui.Alerts"/>\n    </requires>\n    <resources>\n      <xml cache="shared" id="xml" path="jsx:/xml/components/dialog_confirm.xml"/>\n    </resources>\n  </plugin>\n  <plugin id="jsx3.gui.Alerts.prompt">\n    <requires>\n      <plugin id="jsx3.gui.Button"/>\n      <plugin id="jsx3.gui.Alerts"/>\n    </requires>\n    <resources>\n      <xml cache="shared" id="xml" path="jsx:/xml/components/dialog_prompt.xml"/>\n    </resources>\n  </plugin>\n\n  <plugin class="jsx3.amp.Main" id="jsx3.amp.main" name="Controller Plug-In" version="0.1">\n\n    <requires>\n      <plugin id="jsx3.gui.Block"/>\n    </requires>\n\n    <resources>\n      <script id="Main" load="early">\n        <data><![CDATA[jsx3.lang.Class.defineClass("jsx3.amp.Main",jsx3.amp.PlugIn,null,function(r,g){var\nub={a:"Main.onRegister",b:"vu",c:"Main.onExtension ",d:" [",e:"]",f:"progress",g:"init",h:"layout",i:"onComplete",j:"setProgress",k:"Main.onStartup"};var\nw=jsx3.amp;g.onRegister=function(){w.LOG.debug(ub.a);this._progress=jsx3.$A();this._pctdone=0;this._mainComp=null;(this.getEngine()).subscribe(w.Engine.PROGRESS,this,ub.b);this.load();};g.onExtension=function(k,e){this.jsxsuper(k,e);w.LOG.debug(ub.c+k+ub.d+e+ub.e);var\nu=k.getLocalId();if(u==ub.f){(k.processExts(null,e)).each((jsx3.$F(function(c){c.when((jsx3.$F(function(m){m.setProgress(this._pctdone);this._progress.push(m);})).bind(this));})).bind(this));}else if(u==ub.g){(jsx3.$A(e)).each(function(q){(q.getPlugIn()).load();});}else if(u==ub.h)(jsx3.$A(e)).each(function(h){(h.getPlugIn()).load();});};g.vu=function(i){this._pctdone=i.pct;var\nF=i.done?ub.i:ub.j;var\neb=this._pctdone;this._progress.each(function(a){a[F](eb);});};g.onStartup=function(){(this.loaded()).when((jsx3.$F(function(){w.LOG.debug(ub.k);(this.getExtPoint(ub.g)).processExts();var\nha=(this.getExtPoint(ub.h)).processExts();if(ha.length>0){var\nca=(this.getServer()).getBodyBlock();ha[0].when(function(j){j(ca);});}})).bind(this));};});]]></data>\n      </script>\n    </resources>\n\n    \n    <extension-point id="progress" name="Initialization Progress Extension Point">\n      \n      <processor type="return-async"/>\n    </extension-point>\n\n    \n    <extension-point id="init" name="Initialization Extension Point">\n      <processor type="eval"/>\n    </extension-point>\n\n    \n    <extension-point id="layout" name="Main Component Extension Point">\n      \n      <processor type="return-async"/>\n    </extension-point>\n\n  </plugin>\n\n  <plugin class="jsx3.amp.AutoReg" id="jsx3.amp.autoreg" name="Plug-In Auto-Registration Plug-In" version="0.1">\n\n    <resources>\n      <script id="js" load="early">\n        <data><![CDATA[jsx3.lang.Class.defineClass("jsx3.amp.AutoReg",jsx3.amp.PlugIn,null,function(l,q){var\nub={a:"plugins_auto",b:"/",c:"dirlist",d:/^([\\w\\-]+)(\\.[\\w\\-]+)*$/,e:"done"};var\nw=jsx3.amp;l.DIR=ub.a;q.hasProvider=function(){return this._hasProvider;};q.hasCompleted=function(){return this._done;};q.onRegister=function(){this._hasProvider=false;this._done=false;this._uri=(jsx3.app.Browser.getLocation()).resolve((this.getServer()).resolveURI(l.DIR+ub.b));};q.onExtension=function(d,s){this.jsxsuper(d,s);if(d.getLocalId()==ub.c)if(!this._hasProvider)for(var\nA=0;A<s.length;A++){var\nU=s[A];if(U.isAvailable(this._uri.getScheme())){this._hasProvider=true;this._loadWith(U);break;}}};q._loadWith=function(b){((b.getPlugIn()).load()).when((jsx3.$F(function(){var\nZ=b.getDirNames(this._uri);Z=Z.filter(function(r){return r.match(ub.d);});Z.each((jsx3.$F(function(a){(this.getEngine()).register(a,this._uri);})).bind(this));this._done=true;this.publish({subject:ub.e});})).bind(this));};});]]></data>\n      </script>\n    </resources>\n\n    \n    <event id="done"/>\n\n    <extension-point id="dirlist" name="Provide Directory Listing">\n      \n    </extension-point>\n  </plugin>\n\n  <plugin id="jsx3.amp.persist" name="Data Persistance Plug-In" version="0.1">\n\n    <method id="getFirstProvider">\n      return this.getExtPoint("provider").getExts().find(function(e) { return e.isAvailable(); });\n    </method>\n\n    <extension-point id="provider" name="Provide Persistance">\n      \n    </extension-point>\n\n    <extension id="cookie" point="jsx3.amp.persist.provider">\n      <method id="_getKey" params="k">\n        return "com_tibco_gi_amp_persist_" + k;\n      </method>\n\n      <method id="isAvailable">\n        var s = this.getPlugIn().getServer();\n        var k = this._getKey("__test"), v = "foobar";\n        s.setCookie(k, v);\n        var ok = s.getCookie(k) == v;\n        s.deleteCookie(k);\n        return ok;\n      </method>\n\n      <method id="get" params="k">\n        var s = this.getPlugIn().getServer();\n        return s.getCookie(this._getKey(k));\n      </method>\n\n      <method id="put" params="k, v">\n        var s = this.getPlugIn().getServer();\n        s.deleteCookie(this._getKey(k));\n        var now = new Date();\n        s.setCookie(this._getKey(k), v, new Date(now.getFullYear() + 1, now.getMonth(), now.getDate()));\n      </method>\n\n      <method id="remove" params="k">\n        var s = this.getPlugIn().getServer();\n        s.deleteCookie(this._getKey(k));\n      </method>\n    </extension>\n  </plugin>\n\n  <plugin id="jsx3.amp.util.menumgr" name="MenuManager Plug-In" version="0.1">\n    <requires>\n      <plugin id="jsx3.gui.Menu"/>\n    </requires>\n    <resources>\n      <script id="js" path="MenuManager.js"/>\n    </resources>\n  </plugin>\n\n  <plugin id="jsx3.amp.util.toolbarmgr" name="ToolbarManager Plug-In" version="0.1">\n    <requires>\n      <plugin id="jsx3.gui.ToolbarButton"/>\n    </requires>\n    <resources>\n      <script id="js" path="ToolbarManager.js"/>\n    </resources>\n  </plugin>\n\n  <plugin global="true" id="jsx3.amp.util.prefspanel" name="PrefsPane Plug-In" property="jsx3.amp.util.PrefsPane.PLUGIN" version="0.1">\n    <resources>\n      <script id="js" path="PrefsController.js"/>\n      <xml id="controller" path="controller.xml"/>\n    </resources>\n  </plugin>\n\n  <plugin global="true" id="jsx3.amp.util.wizard" name="Wizard Plug-In" property="jsx3.amp.util.Wizard.PLUGIN" version="0.1">\n    <resources>\n      <script id="js" path="Wizard.js"/>\n      <xml id="controller" path="controller.xml"/>\n    </resources>\n  </plugin>\n\n</plugins>',ja:"this.",jb:"amp.33",k:"engine.load",ka:"(evt);",kb:"amp.22",l:"jsx3.amp.autoreg",la:"this.load().when(jsx3.$F(function(){",lb:"amp.25",m:"done",ma:"}).bind(this));",mb:"amp:data",n:"amp.02",na:"loaded",nb:"style",o:"plugins",oa:"if(this.isLoaded()){",ob:"type",p:"",pa:"}",pb:"text/css",q:"plugin",qa:"_evt_",qb:"head",r:"amp.04",ra:/\./g,rb:"beforeEnd",s:"amp.03",sa:"var ",sb:'<style type="text/css">\n',t:"id",ta:" = function(evt){",tb:"\n</style>",u:"class",ua:"}; ",ub:"amp.29",v:"path",va:";",vb:"*",w:"p.",wa:".",wb:"GET",x:"amp.01",xa:"amp.13",xb:"oK",y:"amp.05",ya:"amp.17",yb:"link",z:"amp.06",za:"amp:script | amp:field | amp:method",zb:"stylesheet"};var
na=jsx3.amp;var
wa=jsx3.xml.Document;var
S=jsx3.util.Job;f.LOAD=ub.a;f.ERROR=ub.b;f.REGISTER=ub.c;f.PROGRESS=ub.d;f.BP={};f.z1={};f.getEngine=function(a){var
I=a.getEnv(ub.e);if(!f.BP[I])f.BP[I]=new
f(a);return f.BP[I];};f.Bd=function(b){var
Ab=b.getAddins();for(var
Cb=0;Cb<Ab.length;Cb++)if(Ab[Cb]==na.ADDIN){f.getEngine(b);return;}};f.Cm=function(){var
Mb=jsx3.app.Server;var
ab=Mb.allServers();for(var
pb=0;pb<ab.length;pb++)f.Bd(ab[pb]);Mb.subscribe(Mb.INITED,f,ub.f);};f.CK=function(s){f.Bd(s.target);};jsx3.net.URIResolver.register(ub.g,function(q){var
Lb=q.getHost();for(var Wa in f.BP){var
ga=f.BP[Wa].getPlugIn(Lb);if(ga)return ga;}return null;});p.init=function(r){this.gq=r;this.j5=jsx3.$A();this.zp={};this.fw={__ct:0};this.N4={};this.OC={};this.jx=0;this.kC=jsx3.util.EventDispatcher.jsxclass.newInnerClass();this.sU=0;this.WB={};this.pA={};this.C3=new
db(this);this.BA=false;this.ZK();};p.ZK=jsx3.$Y(function(r){var
kb=new
jsx3.util.Timer(ub.h,(this.getServer()).getEnv(ub.e));var
da=na.DIR+ub.i+na.DESCRIPTOR;var
xa=na.ADDIN.resolveURI(da);var
lb=(new
jsx3.xml.Document()).loadXML(ub.j);var
Ga=this.ZM(lb,xa);Ga.when((jsx3.$F(function(){this.C3.cD();})).bind(this));var
A=f.JO(this.gq.resolveURI(da));var
Pa=this.ZM(A,Ga);var
T=this.dW(Pa);var
za=jsx3.$Z(this.xp,this)(T);za.when(function(){kb.log(ub.k);});return za;});p.dW=jsx3.$Y(function(r){var
Bb=this.getPlugIn(ub.l);(Bb.load()).when(function(){if(Bb.hasProvider()&&!Bb.hasCompleted())Bb.subscribe(ub.m,function(){r.done();});else r.done();});});p.ZM=jsx3.$Y(function(o){var
Mb=(o.args())[0];var
B=(o.args())[1]||Mb.getSourceURL();na.LOG.debug(jsx3._msg(ub.n,B));if(!Mb.hasError()){var
ra=Mb.getBaseName();var
ga=Mb.getNamespaceURI();if(ra==ub.o&&na.isNS(ga)){var
Bb=((new
jsx3.net.URI(B)).resolve(ub.p)).toString();Bb=Bb.substring(0,Bb.length-1);var
P=null;for(var
Y=(Mb.getChildNodes()).iterator();Y.hasNext();){var
Kb=Y.next();if(Kb.getBaseName()==ub.q&&na.isNS(Kb.getNamespaceURI())){var
X=this.sI(Kb,Bb);P=P?P.and(X):X;}}if(P)return P;o.done();}else{na.LOG.error(jsx3._msg(ub.r,ra,ga));this.publish({subject:f.ERROR,xml:Mb});o.done();}}else{na.LOG.error(jsx3._msg(ub.s,Mb.getError()));this.publish({subject:f.ERROR,xml:Mb});o.done();}});p.sI=jsx3.$Y(function(l){var
Eb=(l.args())[0],Ra=(l.args())[1];var
Ba=Eb.getAttribute(ub.t);this.fw[Ba]=this.fw.__ct++;var
_a=Eb.getFirstChild()==null&&Eb.getAttribute(ub.u)==null;var
O=Eb.getAttribute(ub.v);if(O)Ra=((jsx3.net.URI.valueOf(Ra)).resolve(O)).toString();return this.FV(Ra,Ba,_a?null:Eb);});p.FV=jsx3.$Y(function(s){var
D=s.args();var
ob=D[0],Wa=D[1],aa=D[2];this.C3.G3(ub.w+Wa);if(!aa){var
Ta=(ob?ob+ub.i:ub.p)+Wa+ub.i+na.METAFILE;na.LOG.debug(jsx3._msg(ub.x,Ta,Wa));aa=f.JO(Ta);}return this.Oo(ob,Wa,aa);});p.Oo=jsx3.$Y(function(i){var
Ka=i.args();var
B=Ka[0],Va=Ka[1],P=Ka[2];this.C3.gQ(ub.w+Va);if(!P.hasError()){var
La=P.getBaseName();var
u=P.getNamespaceURI();if(La==ub.q&&na.isNS(u)){return this.w0(Va,B,P);}else{na.LOG.error(jsx3._msg(ub.y,Va,La,u));i.done();}}else{na.LOG.error(jsx3._msg(ub.z,Va,P.getError()));i.done();}});p.w0=jsx3.$Y(function(m){var
cb=m.args();var
Ga=cb[0],G=cb[1],Va=cb[2];var
M=Va.getAttribute(ub.t);if(!M||M!=Ga){na.LOG.error(jsx3._msg(ub.A,Ga,M));m.done();}else{var
Nb=na.Md(Va.getAttribute(ub.B),(this.getServer()).getLocale());if(Nb){(this.gZ(G+ub.i+Ga,Va,Nb)).when((jsx3.$F(function(){m.done(this.Q0(Ga,G,Va));})).bind(this));}else return this.Q0(Ga,G,Va);}});p.gZ=jsx3.$Y(function(r){var
ga=r.args();var
Ka=ga[0],ab=ga[1],lb=ga[2];Ka=Ka+(ub.C+lb+ub.D);(f.JO(Ka)).when((jsx3.$F(function(k){if(k&&!k.hasError())this.Rs(ab,k);else na.LOG.error(jsx3._msg(ub.E,Ka,k?k.getError():null));r.done();})).bind(this));});f.r7={script:1,method:1,field:1,processor:1};f.xQ={script:1,method:1,field:1};p.Rs=function(e,g){if(g.getBaseName()!=ub.q||!na.isNS(g.getNamespaceURI())){na.LOG.error(jsx3._msg(ub.F,g.getSourceURL()));return;}(jsx3.$A(g.getAttributeNames())).each(function(l){e.setAttribute(l,g.getAttribute(l));});this.BZ(e,g,ub.G,f.r7);this.BZ(e,g,ub.H,f.xQ);};p.BZ=function(m,r,d,b){for(var
ca=r.selectNodeIterator(ub.I+d+ub.J,na.getXmlNS(r));ca.hasNext();){var
_a=ca.next();var
ua=_a.getAttribute(ub.t);var
qa=m.selectSingleNode(ub.I+d+ub.K+ua+ub.L,na.getXmlNS(m));if(qa){(jsx3.$A(_a.getAttributeNames())).each(function(s){qa.setAttribute(s,_a.getAttribute(s));});var
nb=(_a.getChildNodes()).toArray();if(nb.length>0){(jsx3.$A(((qa.getChildNodes()).toArray()).reverse())).each(function(s){if(!na.isNS(s.getNamespaceURI())||!b[s.getBaseName()])qa.removeChild(s);});(jsx3.$A(nb)).each(function(g){qa.appendChild(g);});}}else na.LOG.error(jsx3._msg(ub.M,m.getAttribute(ub.t),d,ua));}};p.Q0=jsx3.$Y(function(d){var
ib=d.args();var
ea=ib[0],A=ib[1],R=ib[2];this.WB[ea]=R;var
O=this.FW(R.selectSingleNode(ub.N,na.getXmlNS(R)),ea,A);var
Jb=this.jP(ea,R);var
tb=this.hB(ea,O,Jb);return jsx3.$Z(this._F,this)(ea,A,R,O,tb);});p.jP=jsx3.$Y(function(s){var
Xa=s.args();var
t=Xa[0],ea=Xa[1];var
R=this.Q9(ea);R=R.filter((jsx3.$F(function(m){var
fb=this.getPlugIn(m);if(!fb&&!this.fw[m])na.LOG.warn(jsx3._msg(ub.O,t,m));return !fb;})).bind(this));if(R.length>0){var
Wa=(jsx3.$F(function(g){R.remove(g.plugin.getId());if(R.length==0){this.unsubscribe(f.REGISTER,Wa);s.done();}})).bind(this);this.subscribe(f.REGISTER,Wa);}else s.done();});p.hB=jsx3.$Y(function(r){var
Ba=r.args();var
hb=Ba[0],va=Ba[1];var
wb={};va.each(function(e){wb[e.getLocalId()]=e;});this.pA[hb]=wb;var
B=null;va.each((jsx3.$F(function(j){if(j.getLoadType()==na.Resource.LOAD_EARLY){var
ab=this.W1(j);B=B?B.and(ab):ab;}})).bind(this));if(B)return B;r.done();});p.FW=function(h,a,i){var
Hb={};var
ua=jsx3.$A();if(h)for(var
ja=(h.getChildNodes()).iterator();ja.hasNext();){var
Ka=ja.next();if(na.isNS(Ka.getNamespaceURI())){var
T=Ka.getAttribute(ub.t);if(Hb[T]){na.LOG.error(jsx3._msg(ub.P,T,a));T=null;}if(T==null||T==ub.p)T=ub.Q+a+ub.R+
++this.jx;var
Db=na.Resource.wh(a,i+ub.i+a+ub.i,T,Ka,this);for(var
la=Ka.selectNodeIterator(ub.S,na.getXmlNS(Ka));la.hasNext();){var
Ga=la.next();var
ca=Ga.getAttribute(ub.t);if(ca)Db.Bc(ca,ub.T);else Db.Bc(Ga.getAttribute(ub.q),ub.q);}ua.push(Db);Hb[T]=Db;}}return ua;};p.Q9=function(o){var
Va=jsx3.$A();for(var
Ba=o.selectNodeIterator(ub.U,na.getXmlNS(o));Ba.hasNext();)Va.push((Ba.next()).getAttribute(ub.t));return Va;};p.vu=function(){var
ca=this.C3.pct();var
ra={subject:f.PROGRESS,pct:100*ca};if(ca>=1)ra.done=true;this.publish(ra);};p._F=function(a,j,d,r){var
wb=d.getAttribute(ub.V);if(wb&&f.z1[a]){}var
Bb;var
Ea=d.getAttribute(ub.u);if(Ea){Bb=na.Gf(Ea);if(!Bb)na.LOG.error(jsx3._msg(ub.W,Ea,a));}if(!Bb)Bb=na.PlugIn;var
ka=new
Bb();if(typeof ka.setEngine==ub.X)ka.setEngine(this);if(typeof ka.setPath==ub.X)ka.setPath(j+ub.i+a);if(typeof ka.setData==ub.X)ka.setData(d);if(typeof ka.setResources==ub.X)ka.setResources(r);this.j5.push(ka);this.zp[a]=ka;na.LOG.debug(jsx3._msg(ub.Y,ka));var
Db=ka.getExtPoints();for(var
Sa=0;Sa<Db.length;Sa++)this.dg(Db[Sa]);var
mb={};var
ia=ka.getExts();for(var
Sa=0;Sa<ia.length;Sa++){var
P=ia[Sa];var
Ya=P.getPointId();this.qn(P);if(!mb[Ya])mb[Ya]=jsx3.$A();mb[Ya].push(P);}f.Sh(ka,d);for(var Ya in mb){var
Qa=this.N4[Ya];if(Qa){(Qa.getPlugIn()).onExtension(Qa,mb[Ya]);Qa.onExtension(mb[Ya]);}}for(var
Sa=d.selectNodeIterator(ub.Z,na.getXmlNS(d));Sa.hasNext();){var
Cb=Sa.next();var
Ha=Cb.getAttribute(ub.t);ka.addBindableProp(Ha,Cb.getAttribute(ub._));ka[Ha]=null;var
ea=((jsx3.$S(Cb.getAttribute(ub.aa)||ub.p)).trim()).split(ub.ba);(jsx3.$A(ea)).each((jsx3.$F(function(s){if(s)ka.updateBindableOn(Ha,this.kC,s);})).bind(this));ka.subscribe(Ha,this,ub.ca);}(jsx3.$A(ka.getEvents())).each((jsx3.$F(function(s){ka.subscribe(s,this,ub.ca);})).bind(this));this.Ix(ka,d,true);ka.onRegister();this.publish({subject:f.REGISTER,plugin:ka});};p.Ix=function(q,m,d){var
V=d?ub.da:ub.ea;for(var
eb=m.selectNodeIterator(ub.fa+V,na.getXmlNS(m));eb.hasNext();){var
N=eb.next();var
da=(N.getAttribute(ub.ga)).split(ub.ba);var
kb=N.getAttribute(ub.ha);var
Aa=N.getAttribute(ub.ia);var
ta=kb?ub.ja+kb+ub.ka:N.getValue();if(Aa==ub.a){ta=ub.la+ta+ub.ma;}else if(Aa==ub.na)ta=ub.oa+ta+ub.pa;for(var
Ia=0;Ia<da.length;Ia++){var
sb=ub.qa+da[Ia].replace(ub.ra,ub.R)+ub.R+this.sU++;var
Z=jsx3.eval(ub.sa+sb+ub.ta+ta+ub.ua+sb+ub.va);q[sb]=Z;this.kC.subscribe(da[Ia],q,sb);}}};p.qw=function(i){var
I=(jsx3.$O(i)).clone();I.subject=i.target.getId()+ub.wa+i.subject;na.LOG.debug(jsx3._msg(ub.xa,I.subject));this.kC.publish(I);if(window.OpenAjax&&OpenAjax.hub)try{OpenAjax.hub.publish(I.subject,I);}catch(I){na.LOG.error(jsx3._msg(ub.ya,I.subject),jsx3.NativeError.wrap(I));}};f.Sh=function(o,j){for(var
xa=j.selectNodeIterator(ub.za,na.getXmlNS(j));xa.hasNext();){var
B=xa.next();var
M=B.getBaseName();if(ub.Aa==M){try{o.eval(B.getValue());}catch(Kb){na.LOG.error(jsx3._msg(ub.Ba,o),jsx3.NativeError.wrap(Kb));}}else if(ub.Ca==M){try{o[B.getAttribute(ub.t)]=o.eval(B.getValue());}catch(Kb){na.LOG.error(jsx3._msg(ub.Da,B.getAttribute(ub.t),o),jsx3.NativeError.wrap(Kb));}}else if(ub.Ea==M)try{var
Db=B.getAttribute(ub.t);if(B.getAttribute(ub.Fa)==ub.Ga){Ga=this.s0(Db);}else{var
Fa=B.getAttribute(ub.Ha)||ub.p;var
Ga=jsx3.eval(ub.sa+Db+ub.Ia+Fa+ub.Ja+B.getValue()+ub.ua+Db+ub.va);if(B.getAttribute(ub.Ka)==ub.Ga)Ga=jsx3.$Y(Ga);}o[Db]=Ga;}catch(Kb){na.LOG.error(jsx3._msg(ub.La,B.getAttribute(ub.t),o),jsx3.NativeError.wrap(Kb));}(B.getParent()).removeChild(B);}};f.s0=function(e){return function(){(this.load()).when((jsx3.$F(function(k,s){this[k].apply(this,s);})).bind(this,[e,arguments]));};};p.isLoaded=function(){return this.BA;};p.getServer=function(){return this.gq;};p.getPlugIns=function(){return this.j5;};p.getPlugIn=function(m){return this.zp[m];};p.getExtPoint=function(k){return this.N4[k];};p.getExts=function(l){var
Ab=this.OC[l];if(Ab&&Ab.eR){Ab.sort((jsx3.$F(function(Ab,a){var
Aa=this.fw[(Ab.getPlugIn()).getId()]||0;var
xa=this.fw[(a.getPlugIn()).getId()]||0;return Aa>xa?1:Aa==xa?0:-1;})).bind(this));Ab.eR=false;}return Ab||jsx3.$A();};p.register=jsx3.$Y(function(i){var
F=i.args();var
Nb=F[0];var
gb=F[1];var
Kb=F[2];if(this.zp[Nb])throw new
jsx3.IllegalArgumentException(ub.Ma+Nb+ub.wa);this.fw[Nb]=this.fw.__ct++;return this.FV(gb,Nb,Kb);});p.deregister=function(a){var
bb=this.getPlugIn(a);if(bb){this.j5.remove(bb);var
Kb=bb.getExtPoints();for(var
eb=0;eb<Kb.length;eb++)this.Qh(Kb[eb]);var
Y=bb.getExts();for(var
eb=0;eb<Y.length;eb++)this.kj(Y[eb]);delete this.zp[a];delete this.fw[a];delete this.WB[a];delete this.pA[a];}};p.dg=function(d){na.LOG.debug(jsx3._msg(ub.Na,d));this.N4[d.getId()]=d;};p.Qh=function(n){var
v=n.getId();delete this.N4[v];};p.qn=function(s,b){var
xa=s.getPointId();if(!this.OC[xa])this.OC[xa]=jsx3.$A();this.OC[xa].push(s);this.OC[xa].eR=true;na.LOG.debug(jsx3._msg(ub.Oa,s,xa));if(b){var
y=this.N4[xa];if(y){(y.getPlugIn()).onExtension(y,[s]);y.onExtension([s]);}}};p.kj=function(l){var
Za=this.OC[l.getPointId()];if(Za)Za.remove(l);};p.le=jsx3.$Y(function(b){var
jb=(b.args())[0];var
G=this.FC(jb);var
Pa=new
jsx3.util.Timer(ub.h,jb.getId());var
lb=this.it(jb,G);var
Ib=jsx3.$Z(this.HC,this)(jb,lb);Ib.when(function(){Pa.log(ub.Pa);});return Ib;});p.FC=jsx3.$Y(function(s){var
Aa=(s.args())[0];var
Ea=null;var
C=Aa.getRequires();C.each((jsx3.$F(function(d){var
I=this.getPlugIn(d);if(I){if(!I.isLoaded()){var
Mb=I.load();Ea=Ea?Ea.and(Mb):Mb;}}else na.LOG.error(jsx3._msg(ub.Qa,Aa,d));})).bind(this));if(Ea)return Ea;else s.done();});p.it=jsx3.$Y(function(n){var
Db=(n.args())[0];var
Oa=null;var
C=Db.getResources();C.each(function(k){if(!k.isLoaded()&&k.getLoadType()==na.Resource.LOAD_NORMAL){var
T=k.load();Oa=Oa?Oa.and(T):T;}});if(Oa)return Oa;else n.done();});p.HC=function(c){var
Ra=this.WB[c.getId()];if(Ra){delete this.WB[c.getId()];delete this.pA[c.getId()];this.Ix(c,Ra,false);(c.getBindableProps()).each(function(m){c.updateBindable(m);});var
Ja=Ra.getAttribute(ub.Ra);if(Ja)jsx3.lang.setVar(c.isGlobal()?Ja:(c.getServer()).getEnv(ub.e)+ub.wa+Ja,c);}c.qm();na.LOG.debug(jsx3._msg(ub.Sa,c));};p.wo=jsx3.$Y(function(d){var
Ya=(d.args())[0];Ya.Gg();var
F=this.cz(Ya,Ya.getPlugIn());(this.I8(Ya,F)).when(function(a){Ya.td(a);d.done();});});p.W1=jsx3.$Y(function(c){var
sa=c.args();var
fb=sa[0];(this.cz(fb)).when(function(){(fb.load()).when(c);});});p._getSiblingResource=function(o,e){var
mb=o.getPlugIn();return mb?mb.getResource(e):this.pA[o._j][e];};p.cz=jsx3.$Y(function(m){var
W=m.args();var
rb=W[0];var
la=null;var
Ka=rb.bf();Ka.each((jsx3.$F(function(h){var
Db=null;if(h.type==ub.q){var
yb=this.getPlugIn(h.id);if(yb){if(!yb.isLoaded())Db=yb.load();}else na.LOG.error(jsx3._msg(ub.Ta,h.id,rb));}else{var
u=this._getSiblingResource(rb,h.id);if(u){if(!u.isLoaded())Db=u.load();}else na.LOG.error(jsx3._msg(ub.Ua,h.id,rb));}if(Db)la=la?la.and(Db):Db;})).bind(this));if(la)return la;else m.done();});p.xp=function(){this.BA=true;for(var
Ib=0;Ib<this.j5.length;Ib++)this.j5[Ib].onStartup();this.publish({subject:f.LOAD});};p.iF=function(d,h){if(ub.Va==h)return jsx3.getSharedCache();else if(ub.Wa==h)return jsx3.getSystemCache();else return d.getCache();};p.I8=jsx3.$Y(function(o){var
M=(o.args())[0];var
_a=this.getServer();var
eb=M.getPathForLocale(_a.getLocale());var
Gb=M.getType();var
Ba=ub.Xa+M.getId();this.C3.G3(Ba);var
Wa=this.iF(_a,M.attr(ub.Ya));var
ga=M.attr(ub.Za);if(!ga)if(eb&&Wa!=_a.getCache())ga=jsx3.resolveURI(M.getFullPath(eb));else ga=M.getId();if(eb){var
Ua=M.getFullPath(eb);na.LOG.debug(jsx3._msg(ub._a,M,Ua));var
B=(jsx3.$F(function(m){na.LOG.debug(jsx3._msg(ub.ab,M,Ua));this.C3.gQ(Ba);o.done(m);})).bind(this);switch(Gb){case ub.Aa:if(M.attr(ub.gb)==ub.Ga)(f.K5(Ua)).when((jsx3.$F(function(b){if(b!=null){var
Bb=M.getPlugIn()||jsx3;try{var
C=new
jsx3.util.Timer(ub.h,M.getId());Bb.eval(b);C.log(ub.hb);}catch(Kb){na.LOG.error(jsx3._msg(ub.ib,Ua,Bb),jsx3.NativeError.wrap(Kb));}}else na.LOG.error(jsx3._msg(ub.jb,Ua));B();})).bind(this));else (f.QU(Ua)).when(B);break;case ub.bb:(f.KI(Ua)).when(B);break;case ub.cb:(f.JO(Ua)).when((jsx3.$F(function(k){if(Wa)Wa.setDocument(ga,k);_a.JSS.loadXML(k,ga);B(k);})).bind(this));break;case ub.db:jsx3.app.PropsBundle.getPropsAsync(M.getFullPath(),_a.getLocale(),function(qb){_a.LJSS.addParent(qb);B(qb);},_a.getCache());break;case ub.eb:(f.JO(Ua,jsx3.xml.CDF.Document.jsxclass)).when((jsx3.$F(function(m){m.convertProperties((this.getServer()).getProperties());if(Wa)Wa.setDocument(ga,m);B(m);})).bind(this));break;case ub.fb:(f.JO(Ua,jsx3.xml.XslDocument.jsxclass)).when((jsx3.$F(function(r){if(Wa)Wa.setDocument(ga,r);B(r);})).bind(this));break;default:na.LOG.error(jsx3._msg(ub.kb,Gb));B();}}else{na.LOG.debug(jsx3._msg(ub.lb,M));var
tb=M.xml();var
fb=tb.selectSingleNode(ub.mb,na.getXmlNS(tb));var
Ma=null;switch(Gb){case ub.Aa:if(M.attr(ub.gb)==ub.Ga){var
C=new
jsx3.util.Timer(ub.h,M.getId());(M.getPlugIn()||jsx3).eval((fb||tb).getValue());C.log(ub.hb);}else if(!f.DA[M.getId()]){var
C=new
jsx3.util.Timer(ub.h,M.getId());f.DA[M.getId()]=1;jsx3.eval((fb||tb).getValue());C.log(ub.hb);}break;case ub.bb:if(jsx3.CLASS_LOADER.IE){var
ba=document.createElement(ub.nb);ba.setAttribute(ub.ob,ub.pb);(document.getElementsByTagName(ub.qb))[0].appendChild(ba);ba.styleSheet.cssText=((fb||tb).getValue()).toString();}else jsx3.html.insertAdjacentHTML((document.getElementsByTagName(ub.qb))[0],ub.rb,ub.sb+(fb||tb).getValue()+ub.tb);break;case ub.cb:if(fb){_a.JSS.loadXML(fb.getFirstChild(),M.getId());Ma=_a.JSS;}else na.LOG.error(jsx3._msg(ub.ub,M));break;case ub.db:case ub.eb:if(fb){Ma=new
jsx3.xml.CDF.Document(fb.getFirstChild());Ma.convertProperties((this.getServer()).getProperties());if(Wa)Wa.setDocument(ga,Ma);if(Gb==ub.db){var
gb=M.getFullPath(fb.getAttribute(ub.v));if(Wa)Wa.setDocument(gb,Ma);var
qb=jsx3.app.PropsBundle.getProps(gb,_a.getLocale(),objCache);_a.LJSS.addParent(qb);}}else na.LOG.error(jsx3._msg(ub.ub,M));break;case ub.fb:if(fb){Ma=new
jsx3.xml.XslDocument(fb.getFirstChild());if(Wa)Wa.setDocument(ga,Ma);}else na.LOG.error(jsx3._msg(ub.ub,M));break;default:na.LOG.error(jsx3._msg(ub.kb,Gb));}this.C3.gQ(Ba);o.done(Ma);}});f.JO=jsx3.$Y(function(m){var
_a=m.args();var
w=_a[0],fa=_a[1];var
Da=(fa||jsx3.xml.Document.jsxclass).newInstance();Da.setAsync(true);Da.subscribe(ub.vb,function(){m.done(Da);});Da.load(w);});f.K5=jsx3.$Y(function(h){var
X=h.args();var
Da=X[0];var
cb=jsx3.net.Request.open(ub.wb,Da,true);cb.subscribe(ub.vb,function(){h.done(cb.getResponseText());});cb.send();});f.KI=jsx3.$Y(function(l){return this.py((l.args())[0],ub.xb);});f.oK=jsx3.$Y(function(n){var
Gb=(n.args())[0];var
x=document.createElement(ub.yb);x.href=Gb;x.rel=ub.zb;x.type=ub.pb;(document.getElementsByTagName(ub.qb))[0].appendChild(x);n.done();});f.QU=jsx3.$Y(function(q){return this.py((q.args())[0],ub.Ab);});f.h8=jsx3.$Y(function(d){var
ba=(d.args())[0];jsx3.CLASS_LOADER.loadJSFile(ba,function(){d.done();});});f.DA={};f.py=jsx3.$Y(function(r){var
vb=(r.args())[0];var
T=f.DA[vb];if(T){if(T instanceof jsx3.$AsyncRV)return T;else r.done();}else{var
W=(r.args())[1];var
bb=f.DA[vb]=this[W](vb);bb.when(function(){f.DA[vb]=1;});return bb;}});var
db=function(c){this._eng=c;this._ids={};this._total=0;this._donect=0;this._on=0;};(jsx3.$O(db.prototype)).extend({cD:function(){this._on=1;},G3:function(e){if(this._ids[e])na.LOG.warn(jsx3._msg(ub.Bb,e));else if(this._on){this._ids[e]=1;this._total++;this._eng.vu();}else this._ids[e]=-1;},gQ:function(j){var
Z=this._ids[j];if(Z){delete this._ids[j];if(Z>0){this._donect++;this._eng.vu();}}else na.LOG.warn(jsx3._msg(ub.Cb,j));},pct:function(){return this._total>0?this._donect/this._total:0;}});});jsx3.amp.Engine.Cm();