Place user created addins in this folder.
