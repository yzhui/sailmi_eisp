/*
 * Copyright (c) 2001-2010, TIBCO Software Inc.
 * Use, modification, and distribution subject to terms of license.
 */
jsx3.require("jsx3.chart.BarChart");
